import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from sklearn.feature_extraction.text import CountVectorizer
import random


def read_data():
    df = pd.read_csv('train.csv')
    return df.to_numpy()

def tf_idf(data):
    # unique word in the list
    counts = data[:,1]
    counts = counts.astype(np.float)
    length = np.sum(counts)
    # tf = each words frequencies/total of this type of words
    lst_TF = np.divide(counts,length)
    # idf = log (8 types(class) / (each wrods frequencies + 1)
    lst_IDF = [math.log(8/(i+1)) for i in lst_TF]
    # tf_idf = tf * idf
    lst_TF_IDF = np.multiply(lst_TF,lst_IDF)
    # merges words and value of tf_idf and that words frequencies
    frequencies = np.asarray((data[:,0], lst_TF_IDF, counts)).T
    return frequencies[frequencies[:,1].argsort()]

def trainning(X, start, dic,size, size_total):
    #初始化5000个词的后面theta是0
    zero_colomn = np.zeros((len(dic),2))
    new_dic = dic.reshape((len(dic),1))
    new_dic = np.hstack((new_dic, zero_colomn))
    # take all the sample of this category
    #new_x = np.where(X[:,1] == category)
    theta = size / size_total
    # not_x = np.where(X[:,1] != category)
    x = X[start:(start+800)]
    if start == 0:
        not_x = X[(start+800):]
    elif start == (len(X) - 800):
        not_x = X[:len(X) - 800]
    else:
        not_x = np.vstack((X[0:start], X[start+800:]))
    for word in x:
        for theta_k in new_dic:
            if word[0] == theta_k[0]:
                theta_k[1] = float(word[1])/size
    # 计算 cateory = 0 theta（1,k)的prob
    for other in not_x:
        for theta_k in new_dic:
            if other[0] == theta_k[0]:
                theta_k[2] = float(other[1])/(size_total-size)
    return theta, new_dic

def vectorizerData(data):
    vectorizer = CountVectorizer()
    vectorizer.fit_transform(data)
    new_data = list(vectorizer.vocabulary_.items())
    new_data = np.array(new_data)
    return new_data


def main():

    dataset = read_data()
    print("Here is the shape of dataset",dataset.shape)

    # rpg 1989  anime 3293   data science 5675  hardware 7292  car 9356
    # gamernews 10140  gamedev 11156  computer 11583
    # pick 10000 sample, if lease than 10000 pick all
    rpg = dataset[0:1989,0]
    anime = dataset[1989:3293,0]
    datascience = dataset[3293:5675,0]
    hardware = dataset[5675:7292,0]
    car = dataset[7292:9356,0]
    gamernews = dataset[9356:10140,0]
    gamedev = dataset[10140:11155,0]
    computer = dataset[11155:11582,0]
    # tf_idf
    rpg_sortedArr = tf_idf(vectorizerData(rpg))
    anime_sortedArr = tf_idf(vectorizerData(anime))
    datascience_sortedArr = tf_idf(vectorizerData(datascience))
    hardware_sortedArr = tf_idf(vectorizerData(hardware))
    car_sortedArr = tf_idf(vectorizerData(car))
    gamernews_sortedArr = tf_idf(vectorizerData(gamernews))
    gamedev_sortedArr = tf_idf(vectorizerData(gamedev))
    computer_sortedArr = tf_idf(vectorizerData(computer))
    print("rpg: ",len(rpg_sortedArr),'\nanime: ',len(anime_sortedArr),
    "\ndatascience: ",len(datascience_sortedArr), "\nhardware: ",
    len(hardware_sortedArr), "\ncar: ",len(car_sortedArr),"\ngamernews: ",
    len(gamernews_sortedArr),"\ngamernews",len(gamedev_sortedArr),"\ncomputer",
    len(computer_sortedArr))
    # choosing 4800 feature
    feature_a = np.append(rpg_sortedArr[-801:-1,0], anime_sortedArr[-801:-1,0])
    feature_b = np.append(datascience_sortedArr[-801:-1,0], hardware_sortedArr[-801:-1,0])
    feature_c = np.append(car_sortedArr[-801:-1,0], gamernews_sortedArr[-801:-1,0])
    feature_d = np.append(gamedev_sortedArr[-801:-1,0],computer_sortedArr[-801:-1,0])
    feature_e = np.append(feature_a,feature_b)
    feature_f = np.append(feature_c,feature_d)
    feature_6400 = np.append(feature_e,feature_f)
    # 提取 unique, 打乱顺序取前面5000个
    feature_5000 = np.unique(feature_6400)
    random.shuffle(feature_5000)
    feature_5000 = feature_5000[:5000]
    merge = np.vstack((rpg_sortedArr[-801:-1], anime_sortedArr[-801:-1],
                    datascience_sortedArr[-801:-1], hardware_sortedArr[-801:-1],
                    car_sortedArr[-801:-1], gamernews_sortedArr[-801:-1],
                    gamedev_sortedArr[-801:-1],computer_sortedArr[-801:-1]))

    # #时间有点长就直接存本地了
    # rpg_theta, rpg_dic = trainning(merge, 0, feature_5000, len(rpg), len(dataset))
    # np.save("rpg",rpg_dic)
    # anime_theta, anime_dic = trainning(merge, 800, feature_5000, len(anime), len(dataset))
    # np.save("anime",anime_dic)
    # datascience_theta, datascience_dic = trainning(merge, 1600, feature_5000, len(datascience), len(dataset))
    # np.save("datascience",datascience_dic)
    # hardware_theta, hardware_dic = trainning(merge, 2400, feature_5000, len(hardware), len(dataset))
    # np.save("hardware",hardware_dic)
    # car_theta, car_dic = trainning(merge, 3200, feature_5000, len(car), len(dataset))
    # np.save("car",car_dic)
    # gamernews_theta, gamernews_dic = trainning(merge, 4000, feature_5000, len(gamernews), len(dataset))
    # np.save("gamernews",gamernews_dic)
    # gamede_theta, gamedev_dic = trainning(merge, 4800, feature_5000, len(gamedev), len(dataset))
    # np.save("gamedev",gamedev_dic)
    # computer_theta, computer_dic = trainning(merge, 5600, feature_5000, len(computer), len(dataset))
    # np.save("computer",computer_dic)

main()
